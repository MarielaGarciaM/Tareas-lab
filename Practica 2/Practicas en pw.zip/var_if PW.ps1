﻿$pasw1 = Read-Host "Introduce tu clave: "
$pasw2 = Read-Host "confirma tu clave: "
if ($pasw1 -eq $pasw2 )
{
    Write-Host "Las claves no coinciden:("
}
else
{
    Write-Host "Nueva clave configurada es correcta!"
}