﻿function Show-Message {
param([Parameter(Mandatory)] [string] $Name, [Parameter(Mandatory)] [ValidateSet(62,64,66,68,70)] [int] $Grupo)
write-host "Mi nombre es: " $Name "Soy del grupo" $Grupo
}
