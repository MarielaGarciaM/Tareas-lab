﻿$Num = 20
$Sum = 0 
For ($i = 1; $i -le $Num ; $i++)
{
    $Sum = $Sum + $i
    }
"La suma de $Num los numeros naturales son $Sum"