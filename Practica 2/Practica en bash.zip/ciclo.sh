#!/bin/bash

$serie

echo "scrpit  de una serie de dos en dos" $serie
for i in {0..100..2}
do
	echo "Bucle: " $i
done 
