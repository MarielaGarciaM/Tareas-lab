#include <iostream>
using namespace std;

int main() 
{
  cout << "HOLA MUNDI:)" ;
  return 0;
}
